public class Orco {

    Orco o = new Orco();

    public Orco(Posicion p){
        this.p = p;
    }
    public Posicion p = new Posicion(2,-2);

    public int energia;
    public void setEnergia(int energia){
        for(int cont = 1; cont <= o.getNivel(); cont++){
            energia = energia + 150;
        }
        this.energia = energia;
    }
    public int getEnergia(){
        return energia;
    }

    public int nivel;

    public void setNivel(int nivel){
        this.nivel = nivel;
    }
    public int getNivel(){
        return nivel;
    }

    public void atacar(Guerrero g){
        if(g.p.getX() >= o.p.getX()){
            for(int cont = 1; cont < o.p.getX() - g.p.getX(); cont++){
                g.setEnergia(g.getEnergia() - 100/cont - (int) (Math.random()*20/cont + 0));
            }
        } else if(o.p.getX() < g.p.getX()){
            for(int cont = 1; cont < g.p.getX() - p.p.getX(); cont++){
                g.setEnergia(g.getEnergia() - 100/cont - (int) (Math.random()*20/cont + 0));
            }
        }

        if(o.getNivel() > 1){
            g.setEnergia(g.getEnergia() - o.getNivel() * 10);
        }
    }

    public void recuperarse(){
        o.setEnergia(30 + o.getNivel() * 10 );
    }

    public Orco(){
        this.setNivel(1);
        this.setEnergia(energia = 900 + ((int) Math.random() + 100 * 100));
    }
}