public class Guerrero {
    
    Guerrero g = new Guerrero();

    public Guerrero(Posicion p){
        this.p = p;
    }
    public Posicion p = new Posicion(-2,2);

    public int energia;
    public void setEnergia(int energia){
        this.energia = energia;
    }
    public int getEnergia(){
        return energia;
    }

    public boolean escudo;
    public void setEscudo(boolean escudo){
        this.escudo = escudo;
    }
    public boolean getEscudo(){
        return escudo;
    }

    public char arma;
    public void setArma(char arma){
        if(arma == 'A'){
            this.arma = 'A';
        } else if(arma == 'E'){
            this.arma = 'E';
        } else{
            this.arma = 'P';
        }
    }
    public char getArma(){
        return arma;
    }

    public void atacar(Orco o){
        //ESPADA
        if(g.getArma() == 'E' && o.p.getX() >= g.p.getX()){
            for(int cont = 1; cont < o.p.getX() - g.p.getX(); cont++){
                o.setEnergia(o.getEnergia() - 80/cont - (int) (Math.random()*40/cont + 0));
            }
        } else if(g.getArma() == 'E' && o.p.getX() < g.p.getX()){
            for(int cont = 0; cont < g.p.getX() - p.p.getX(); cont++){
                o.setEnergia(o.getEnergia() - 80/cont - (int) (Math.random()*40/cont + 0));
            }
        }

        if(g.getArma() == 'E' && o.p.getY() >= g.p.getY()){
            for(int cont = 1; cont < o.p.getY() - g.p.getY(); cont++){
                o.setEnergia(o.getEnergia() - 80/cont - (int) (Math.random()*40/cont + 0));
            }
        } else if(g.getArma() == 'E' && o.p.getY() < g.p.getY()){
            for(int cont = 1; cont < g.p.getY() - p.p.getY(); cont++){
                o.setEnergia(o.getEnergia() - 80/cont - (int) (Math.random()*40/cont + 0));
            }
        }
        //ARCO
        if(g.getArma() == 'A' && o.p.getX() >= g.p.getX()){
            for(int cont = 1; cont < o.p.getX() - g.p.getX(); cont++){
                o.setEnergia(o.getEnergia() - 5*cont - (int) (Math.random()*40/cont + 0));
            }
        } else if(g.getArma() == 'A' && o.p.getX() < g.p.getX()){
            for(int cont = 1; cont < g.p.getX() - p.p.getX(); cont++){
                o.setEnergia(o.getEnergia() - 5*cont - (int) (Math.random()*40/cont + 0));
            }
        }

        if(g.getArma() == 'A' && o.p.getY() >= g.p.getY()){
            for(int cont = 1; cont < o.p.getY() - g.p.getY(); cont++){
                o.setEnergia(o.getEnergia() - 5*cont - (int) (Math.random()*40/cont + 0));
            }
        } else if(g.getArma() == 'A' && o.p.getY() < g.p.getY()){
            for(int cont = 1; cont < g.p.getY() - p.p.getY(); cont++){
                o.setEnergia(o.getEnergia() - 5*cont - (int) (Math.random()*40/cont + 0));
            }
        }
        System.out.printf("Vida Orco: %d \n", o.getEnergia());
    }

    public void recuperarse(){
        g.setEnergia(g.getEnergia() + (int) Math.random() * 100 + 25);
        System.out.printf("Te has recuperado %d pts de vida \n", g.getEnergia());
    }

    public Guerrero(){
        this.setEnergia(energia = 750 + ((int) Math.random() + 100 * 100));
    }
}
