import java.util.Scanner;

public class Posicion {

    Posicion p = new Posicion();
    
    public int x;
    public void setX(int x){
        if(x < 1){
            this.x = 1;
        }else if(x > 5){
            this.x = 5;
        }else{
            this.x = x;
        }
    }
    public int getX(){
        return x;
    }

    public int y;
    public void setY(int y){
        if(y < 1){
            this.y = 1;
        }else if(y > 5){
            this.y = 5;
        }else{
            this.y = y;
        }
    }
    public int getY(){
        return y;
    }

    public Posicion(){
        x = 0;
        y = 0;
    }

    public Posicion(int x, int y){
        this.x = x;
        this.y = y;
    }

    public void moverA(){
        Scanner sc = new Scanner(System.in);

        System.out.println("A donde te quieres mover?");
        p.setX(sc.nextInt());
        p.setY(sc.nextInt());
        System.out.printf("Te has desplazado a %d,%d", p.getX(), p.getY());
    }

    public void desplazarA(){
        Scanner sc = new Scanner(System.in);

        System.out.println("A que direccion quieres desplazarte?");
        String lugar = sc.nextLine();
        switch (lugar) {
            case "arriba":
                p.setX(p.getX() + 1);
                break;
            case "abajo":
                p.setX(p.getX() - 1);
                break;
            case "derecha":
                p.setY(p.getY() + 1);
                break;
            case "izquierda":
                p.setY(p.getY() - 1);
                break;
        
            default:
                System.out.println("direccion no valida");
                break;
        }
    }
}
