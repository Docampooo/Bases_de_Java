import java.util.Scanner;
public class Principal {

        public static void help(){
            System.out.printf("\n-Para desplazarte por el mapa, escribe la direccion: arriba, abajo, derecha, izquierda.\n-Atacar: inflige daño al orco dependiendo de tu arma, el arco hace daño a mas distancia pero pega menos que la espada.\n-Recuperarse: regenera una cantidad minima de vida mas una cantidad aleatoria.");
        }

        public static void patronOrco(Orco o){
            Scanner sc = new Scanner(System.in);

            int eleccion = 0;

                System.out.println("1º Atacar");
                System.out.println("2º Recuperarse");
                System.out.println("3º Desplazarse");
                System.out.println("4º Moverse (lejos)");
                eleccion = sc.nextInt();
                switch (eleccion) {
                case 1:
                    o.atacar(Guerrero g);
                    break;
                case 2:
                    o.recuperarse();
                    break;
                case 3:
                    o.p.desplazarA();
                    break;
                case 4:
                    o.p.moverA();
                    break;
            
                default:
                    System.out.println("Opcion fuera de rango");
                    break;
            }
        }
        public static void main(String[] args) {
            
        Scanner sc = new Scanner(System.in);
    
        Orco o = new Orco();  //Al colocar aqui el orco, sale un exception y no encuentro dónde está el problema
        Guerrero g = new Guerrero();
    
        System.out.println("Bienvenido a las mazmorras, contigo se encuentras un orco al que tendras que derrotar, escribe help para la ayuda de controles");
        
        int eleccion = 0;
        do{
            System.out.println("1º Atacar");
            System.out.println("2º Recuperarse");
            System.out.println("3º Desplazarse");
            System.out.println("4º Moverse (lejos)");
            eleccion = sc.nextInt();
            switch (eleccion) {
            case 1:
                
                break;
            case 2:
                g.recuperarse();
                break;
            case 3:
                g.p.desplazarA();
                break;
            case 4:
                g.p.moverA();
                break;
        
            default:
                System.out.println("Opcion fuera de rango");
                break;
        }
        patronOrco(Orco o);
    }while (eleccion == 5);

    


    }
}
